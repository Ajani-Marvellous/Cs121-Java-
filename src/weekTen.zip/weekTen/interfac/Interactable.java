package weekTen.interfac;

public interface Interactable {
    void interact();
}
