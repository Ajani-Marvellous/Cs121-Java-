package weekTen.interfac;

public class staffInterface implements Interactable {
    @Override
    public void interact() {
        System.out.println("Staff is managing tables and handling orders.");
    }
}
