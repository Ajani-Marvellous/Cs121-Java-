package weekTen.interfac;

public class testInterface {
    public static void main(String[] args) {
        Interactable customer = new customerInterface();
        Interactable staff = new staffInterface();

        customer.interact();
        staff.interact();
    }
}
