public class Archer extends Character implements Fighter {
    // Attribute
    private int agility;

    // Constructor
    public Archer(String name, int health, int agility) {
        super(name, health); // Call superclass constructor
        this.agility = agility;
    }

    // Implement attack method
    @Override
    public void attack() {
        System.out.println(name + " shoots an arrow! Agility: " + agility);
    }

    // Implement defend method
    @Override
    public void defend() {
        System.out.println(name + " dodges the attack swiftly.");
    }
}

