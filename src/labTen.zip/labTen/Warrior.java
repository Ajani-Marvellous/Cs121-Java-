package labTen;

public class Warrior {
}
