package labTen;

public class Mage {
}
