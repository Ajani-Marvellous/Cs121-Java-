package labTen;

public class Character {
}
