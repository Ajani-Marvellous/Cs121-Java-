package labTen;

public class Fighter {
}
